document
  .getElementById("email-info-icon-question-mark")
  .addEventListener("click", function () {
    const infoBox = document.getElementById("email-info-box");

    // Toggle de zichtbaarheid van de info-box
    if (infoBox.style.display === "block") {
      infoBox.style.display = "none"; // Verberg de info-box
    } else {
      infoBox.style.display = "block"; // Toon de info-box
    }
  });
